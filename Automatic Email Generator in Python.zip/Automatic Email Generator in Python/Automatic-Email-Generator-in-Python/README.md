# Automatic-Email-Generator-in-Python
This project intends to aid in sending a single email to a large number of people with their names. Just create a contacts.txt file with the names and emails of all the recipients and edit the sender email address in this code to your email address.
